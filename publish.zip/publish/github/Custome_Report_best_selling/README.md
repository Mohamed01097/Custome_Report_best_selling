# Custome_Report_best_selling
this repo contain an odoo15 module that generate a custom report for showing the best selling products between a range of dates
